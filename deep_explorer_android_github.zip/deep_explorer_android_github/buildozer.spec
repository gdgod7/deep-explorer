[app]

# Identidade
title = Deep Explorer
package.name = deepexplorer
package.domain = com.deepexplorer

# Pasta que contém main.py
source.dir = game
source.include_exts = py,txt,png,jpg,jpeg,ttf,wav,ogg
version = 1.0

# Pygame para Android
requirements = python3,pygame

# Tela horizontal, como no jogo original 900x400
orientation = landscape
fullscreen = 1

# Android
android.api = 35
android.minapi = 23
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_license = True

# Não precisamos de permissões especiais
android.permissions =

# Nome do arquivo principal
entrypoint = main.py

[buildozer]

log_level = 2
warn_on_root = 1
