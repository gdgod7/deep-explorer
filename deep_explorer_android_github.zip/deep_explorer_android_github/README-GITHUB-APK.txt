DEEP EXPLORER - COMPILACAO APK PELO GITHUB ACTIONS

Este projeto preserva o codigo original Pygame do Deep Explorer e adiciona apenas a adaptacao minima de toque para Android.

COMO USAR PELO CELULAR:
1. Crie um repositorio no GitHub.
2. Envie TODOS os arquivos deste projeto para o repositorio, mantendo a pasta .github/workflows/android.yml.
3. No GitHub, abra Actions > Build Deep Explorer APK.
4. Se necessario, habilite Actions para o repositorio.
5. Clique em Run workflow.
6. Aguarde a compilacao.
7. Abra a execucao concluida e baixe o artifact chamado deep-explorer-apk.
8. Extraia o artifact e instale o arquivo .apk no Android.

O workflow usa a action Buildozer e executa `buildozer android debug`. O APK e publicado como artifact do GitHub Actions.
