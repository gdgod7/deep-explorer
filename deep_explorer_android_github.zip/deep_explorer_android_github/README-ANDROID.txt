DEEP EXPLORER — ANDROID (CONVERSÃO FIEL)

Esta versão NÃO é uma reescrita em HTML5.
O código original em Pygame foi mantido como base. A única adaptação de jogo
é o tratamento mínimo de toque para Android:

- toque na parte superior: subir/pular
- toque na parte inferior: mergulhar
- soltar o toque: parar de mergulhar
- toque na tela inicial: começar
- toque após Game Over: reiniciar

A física, velocidade, obstáculos, pontuação, recorde, desenho e lógica do jogo
continuam sendo os do código original.

Arquivos:
- game/main.py                -> versão Android, baseada diretamente no original
- game/ocean_explorer_completo.py -> código original preservado
- buildozer.spec              -> configuração para gerar APK

COMO GERAR O APK
1. Em Linux/WSL com Buildozer instalado:
   pip install buildozer
2. Entre nesta pasta.
3. Execute:
   buildozer android debug
4. O APK aparecerá na pasta bin/.

Observação:
O ambiente desta conversa não possui a cadeia Android/Buildozer necessária
para compilar e assinar um APK. Por isso o pacote entregue é o projeto
Android pronto para compilação, não um APK já compilado.

IMPORTANTE
O arquivo .exe original também foi preservado fora deste projeto e não foi
usado para reescrever o jogo. A fonte Pygame original é a referência.
