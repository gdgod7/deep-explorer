"""
OCEAN EXPLORER RUNNER
======================
Jogo estilo "Dino Runner" (do Chrome) com tema de tecnologia de
exploracao maritima. Voce controla um submarino de pesquisa que
precisa desviar de rochas, minas navais, destrocos de naufragios
e enxames de agua-viva, enquanto coleta "dados de pesquisa"
(itens dourados) para ganhar pontos extras.

CONTROLES
---------
    ESPACO / SETA CIMA .... subir (pular sobre obstaculos do fundo)
    SETA BAIXO ............ mergulhar / abaixar (passar sob agua-vivas)
    R ..................... reiniciar (depois do Game Over)
    ESC .................... sair

REQUISITO
---------
    pip install pygame
"""

import math
import os
import random
import sys

import pygame

# ----------------------------------------------------------------------
# CONFIGURACOES GERAIS
# ----------------------------------------------------------------------
LARGURA, ALTURA = 900, 400
FPS = 60
CHAO_Y = ALTURA - 60

PASTA_ATUAL = os.path.dirname(os.path.abspath(__file__))
ARQUIVO_RECORDE = os.path.join(PASTA_ATUAL, "recorde_ocean_explorer.txt")

# Paleta de cores (tema oceanico)
AZUL_PROFUNDO = (5, 20, 55)
AZUL_SUPERFICIE = (100, 190, 220)
AREIA = (194, 178, 128)
AREIA_ESCURA = (150, 130, 90)
BRANCO = (240, 248, 255)
AMARELO = (255, 210, 60)
VERMELHO = (220, 70, 70)
ROXO_MEDUSA = (190, 110, 205)
CINZA_ROCHA = (95, 100, 105)
DOURADO = (255, 200, 40)


def carregar_recorde():
    try:
        with open(ARQUIVO_RECORDE, "r") as arquivo:
            return int(arquivo.read().strip())
    except (FileNotFoundError, ValueError):
        return 0


def salvar_recorde(valor):
    try:
        with open(ARQUIVO_RECORDE, "w", encoding="utf-8") as arquivo:
            arquivo.write(str(int(valor)))
    except OSError:
        # O jogo continua funcionando mesmo sem conseguir gravar o recorde.
        pass


# ----------------------------------------------------------------------
# JOGADOR: SUBMARINO DE PESQUISA
# ----------------------------------------------------------------------
class Submarino:
    LARGURA_NORMAL = 60
    ALTURA_NORMAL = 50
    LARGURA_MERGULHO = 74
    ALTURA_MERGULHO = 25

    def __init__(self):
        self.x = 90
        self.y = float(CHAO_Y - self.ALTURA_NORMAL)
        self.vel_y = 0.0
        self.gravidade = 0.9
        self.impulso = -15.5
        self.no_chao = True
        self.mergulhando = False
        self.frame = 0
        self._contador_frame = 0
        self.rect = pygame.Rect(self.x, self.y, self.LARGURA_NORMAL, self.ALTURA_NORMAL)

    def pular(self):
        if self.no_chao and not self.mergulhando:
            self.vel_y = self.impulso
            self.no_chao = False

    def iniciar_mergulho(self):
        if self.no_chao:
            self.mergulhando = True

    def parar_mergulho(self):
        self.mergulhando = False

    def _dimensoes(self):
        if self.mergulhando:
            return self.LARGURA_MERGULHO, self.ALTURA_MERGULHO
        return self.LARGURA_NORMAL, self.ALTURA_NORMAL

    def atualizar(self):
        if not self.no_chao:
            self.vel_y += self.gravidade
            self.y += self.vel_y
            _, altura = self._dimensoes()
            if self.y >= CHAO_Y - altura:
                self.y = float(CHAO_Y - altura)
                self.vel_y = 0.0
                self.no_chao = True

        largura, altura = self._dimensoes()
        y_atual = (CHAO_Y - altura) if self.no_chao else self.y
        self.rect = pygame.Rect(self.x, int(y_atual), largura, altura)

        self._contador_frame += 1
        if self._contador_frame >= 6:
            self._contador_frame = 0
            self.frame = 1 - self.frame

    def desenhar(self, tela):
        r = self.rect
        cor_casco = (205, 210, 215)
        cor_faixa = (180, 55, 55)
        cor_vidro = (150, 225, 250)
        cor_escuro = (20, 20, 30)

        if self.mergulhando:
            pygame.draw.ellipse(tela, cor_casco, r)
            faixa = pygame.Rect(r.x + 4, r.bottom - 7, r.width - 8, 5)
            pygame.draw.ellipse(tela, cor_faixa, faixa)
            olho_x = r.right - 20
            pygame.draw.circle(tela, cor_vidro, (olho_x, r.centery), 7)
            pygame.draw.circle(tela, cor_escuro, (olho_x, r.centery), 3)
        else:
            corpo = pygame.Rect(r.x, r.y + 8, r.width - 12, r.height - 8)
            pygame.draw.ellipse(tela, cor_casco, corpo)

            faixa = pygame.Rect(corpo.x + 4, corpo.bottom - 8, corpo.width - 8, 6)
            pygame.draw.ellipse(tela, cor_faixa, faixa)

            torre = pygame.Rect(r.x + 16, r.y, 22, 15)
            pygame.draw.ellipse(tela, cor_casco, torre)
            pygame.draw.line(tela, (70, 70, 80), (r.x + 27, r.y + 3), (r.x + 27, r.y - 9), 3)

            pygame.draw.circle(tela, cor_vidro, (r.right - 24, corpo.centery), 8)
            pygame.draw.circle(tela, cor_escuro, (r.right - 24, corpo.centery), 4)

            desloc = 3 if self.frame == 0 else -3
            hx = r.x - 1
            pygame.draw.line(tela, (90, 90, 100), (hx, corpo.centery - 9 + desloc),
                              (hx, corpo.centery + 9 - desloc), 3)


# ----------------------------------------------------------------------
# OBSTACULOS
# ----------------------------------------------------------------------
class Obstaculo:
    def __init__(self, x, y, largura, altura, cor):
        self.rect = pygame.Rect(x, y, largura, altura)
        self.cor = cor

    def atualizar(self, velocidade):
        self.rect.x -= velocidade

    def fora_da_tela(self):
        return self.rect.right < 0

    def hitbox(self):
        return self.rect.inflate(-6, -6)

    def desenhar(self, tela):
        pygame.draw.rect(tela, self.cor, self.rect)


class Rocha(Obstaculo):
    """Formacao rochosa no leito oceanico. Desvie pulando por cima."""

    def __init__(self, x):
        altura = random.randint(32, 52)
        largura = random.randint(32, 46)
        super().__init__(x, CHAO_Y - altura, largura, altura, CINZA_ROCHA)
        self._pontos = [
            (0, altura),
            (largura * 0.15, altura * 0.35),
            (largura * 0.5, 0),
            (largura * 0.85, altura * 0.4),
            (largura, altura),
        ]

    def desenhar(self, tela):
        pts = [(self.rect.x + px, self.rect.y + py) for px, py in self._pontos]
        pygame.draw.polygon(tela, self.cor, pts)
        pygame.draw.polygon(tela, (55, 60, 65), pts, 2)


class MinaNaval(Obstaculo):
    """Mina naval antiga presa ao fundo. Desvie pulando por cima."""

    def __init__(self, x):
        raio = 17
        super().__init__(x, CHAO_Y - raio * 2 + 5, raio * 2, raio * 2, (42, 42, 48))
        self.raio = raio

    def desenhar(self, tela):
        cx, cy = self.rect.center
        pygame.draw.circle(tela, (48, 48, 54), (cx, cy), self.raio)
        pygame.draw.circle(tela, (22, 22, 26), (cx, cy), self.raio, 2)
        for angulo in range(0, 360, 45):
            rad = math.radians(angulo)
            x2 = cx + (self.raio + 8) * math.cos(rad)
            y2 = cy + (self.raio + 8) * math.sin(rad)
            pygame.draw.line(tela, (26, 26, 30), (cx, cy), (x2, y2), 3)
            pygame.draw.circle(tela, (65, 65, 70), (int(x2), int(y2)), 2)


class Medusa(Obstaculo):
    """Agua-viva flutuante. Desvie mergulhando (abaixando) para passar por baixo."""

    LARGURA = 30
    ALTURA = 22

    def __init__(self, x):
        base_bottom = CHAO_Y - 35 + random.randint(-4, 4)
        y = base_bottom - self.ALTURA
        super().__init__(x, y, self.LARGURA, self.ALTURA, ROXO_MEDUSA)
        self._y_base = y
        self._tempo = random.uniform(0, math.tau)

    def atualizar(self, velocidade):
        super().atualizar(velocidade)
        self._tempo += 0.08
        self.rect.y = int(self._y_base + math.sin(self._tempo) * 3)

    def desenhar(self, tela):
        pygame.draw.ellipse(tela, self.cor, self.rect)
        pygame.draw.ellipse(tela, (140, 70, 155), self.rect, 2)
        for i in range(4):
            fx = self.rect.x + 5 + i * 7
            fy1 = self.rect.bottom - 2
            fy2 = fy1 + 10 + int(4 * math.sin(self._tempo * 2 + i))
            pygame.draw.line(tela, self.cor, (fx, fy1), (fx, fy2), 3)


class DetritoNaufragio(Obstaculo):
    """Destrocos de um naufragio antigo. Desvie pulando por cima."""

    def __init__(self, x):
        largura, altura = 20, random.randint(55, 72)
        super().__init__(x, CHAO_Y - altura, largura, altura, (100, 74, 46))

    def desenhar(self, tela):
        pygame.draw.rect(tela, self.cor, self.rect, border_radius=3)
        for i in range(3):
            yy = self.rect.y + 8 + i * (self.rect.height // 3)
            pygame.draw.line(tela, (65, 48, 30), (self.rect.x, yy), (self.rect.right, yy), 2)


# ----------------------------------------------------------------------
# COLETAVEL: DADOS DE PESQUISA (bonus de pontos)
# ----------------------------------------------------------------------
class DadoPesquisa:
    RAIO = 10

    def __init__(self, x):
        y = CHAO_Y - random.choice([55, 95, 135, 165])
        self.rect = pygame.Rect(x, y, self.RAIO * 2, self.RAIO * 2)

    def atualizar(self, velocidade):
        self.rect.x -= velocidade

    def fora_da_tela(self):
        return self.rect.right < 0

    def desenhar(self, tela):
        cx, cy = self.rect.center
        pygame.draw.circle(tela, DOURADO, (cx, cy), self.RAIO)
        pygame.draw.circle(tela, (150, 110, 10), (cx, cy), self.RAIO, 2)
        pygame.draw.circle(tela, BRANCO, (cx - 3, cy - 3), 3)


# ----------------------------------------------------------------------
# BOLHAS DE FUNDO (decoracao)
# ----------------------------------------------------------------------
class Bolha:
    def __init__(self):
        self.x = random.randint(0, LARGURA)
        self.y = random.randint(0, ALTURA)
        self.raio = random.randint(2, 6)
        self.vel = random.uniform(0.5, 1.8)

    def atualizar(self):
        self.y -= self.vel
        if self.y < -10:
            self.x = random.randint(0, LARGURA)
            self.y = ALTURA + random.randint(0, 40)
            self.raio = random.randint(2, 6)
            self.vel = random.uniform(0.5, 1.8)

    def desenhar(self, tela):
        pygame.draw.circle(tela, (200, 230, 255), (int(self.x), int(self.y)), self.raio, 1)


# ----------------------------------------------------------------------
# CENARIO
# ----------------------------------------------------------------------
def desenhar_gradiente_oceano(tela):
    for i in range(ALTURA):
        prop = i / ALTURA
        r = int(AZUL_SUPERFICIE[0] + (AZUL_PROFUNDO[0] - AZUL_SUPERFICIE[0]) * prop)
        g = int(AZUL_SUPERFICIE[1] + (AZUL_PROFUNDO[1] - AZUL_SUPERFICIE[1]) * prop)
        b = int(AZUL_SUPERFICIE[2] + (AZUL_PROFUNDO[2] - AZUL_SUPERFICIE[2]) * prop)
        pygame.draw.line(tela, (r, g, b), (0, i), (LARGURA, i))


def desenhar_chao(tela, deslocamento):
    pygame.draw.rect(tela, AREIA, (0, CHAO_Y, LARGURA, ALTURA - CHAO_Y))
    passo = 40
    x = -int(deslocamento) % passo - passo
    while x < LARGURA:
        pygame.draw.line(tela, AREIA_ESCURA, (x, CHAO_Y + 5), (x + 20, CHAO_Y + 5), 3)
        x += passo
    pygame.draw.line(tela, (172, 156, 112), (0, CHAO_Y), (LARGURA, CHAO_Y), 2)


# ----------------------------------------------------------------------
# LOGICA DO JOGO
# ----------------------------------------------------------------------
def novo_jogo():
    return {
        "submarino": Submarino(),
        "obstaculos": [],
        "coletaveis": [],
        "velocidade": 7.0,
        "pontuacao": 0.0,
        "distancia": 0.0,
        "cronometro_spawn": 0,
        "proximo_spawn": random.randint(55, 95),
        "cronometro_coletavel": random.randint(150, 260),
        "novo_recorde": False,
    }


def sortear_obstaculo(x):
    classe = random.choices(
        [Rocha, MinaNaval, Medusa, DetritoNaufragio],
        weights=[35, 25, 25, 15],
        k=1,
    )[0]
    return classe(x)


def atualizar_jogando(jogo, highscore):
    """Executa um passo de simulacao do jogo. Retorna (colidiu, highscore_atualizado)."""
    sub = jogo["submarino"]
    sub.atualizar()

    jogo["velocidade"] = min(16.0, 7.0 + jogo["pontuacao"] / 220)
    vel = jogo["velocidade"]

    jogo["cronometro_spawn"] += 1
    if jogo["cronometro_spawn"] >= jogo["proximo_spawn"]:
        jogo["cronometro_spawn"] = 0
        jogo["proximo_spawn"] = random.randint(50, 95)
        jogo["obstaculos"].append(sortear_obstaculo(LARGURA + 20))

    jogo["cronometro_coletavel"] -= 1
    if jogo["cronometro_coletavel"] <= 0:
        jogo["cronometro_coletavel"] = random.randint(160, 280)
        jogo["coletaveis"].append(DadoPesquisa(LARGURA + 20))

    for obs in jogo["obstaculos"]:
        obs.atualizar(vel)
    jogo["obstaculos"] = [o for o in jogo["obstaculos"] if not o.fora_da_tela()]

    for col in jogo["coletaveis"]:
        col.atualizar(vel)
    jogo["coletaveis"] = [c for c in jogo["coletaveis"] if not c.fora_da_tela()]

    colidiu = any(sub.rect.colliderect(o.hitbox()) for o in jogo["obstaculos"])

    for col in jogo["coletaveis"][:]:
        if sub.rect.colliderect(col.rect):
            jogo["coletaveis"].remove(col)
            jogo["pontuacao"] += 25

    jogo["pontuacao"] += vel * 0.045
    jogo["distancia"] += vel

    if colidiu and jogo["pontuacao"] > highscore:
        jogo["novo_recorde"] = True
        highscore = jogo["pontuacao"]
        salvar_recorde(highscore)

    return colidiu, highscore


# ----------------------------------------------------------------------
# PROGRAMA PRINCIPAL
# ----------------------------------------------------------------------
def main():
    pygame.init()
    tela = pygame.display.set_mode((LARGURA, ALTURA))
    pygame.display.set_caption("Ocean Explorer - Dino Runner Maritimo")
    relogio = pygame.time.Clock()

    fonte_grande = pygame.font.SysFont("consolas", 40, bold=True)
    fonte_media = pygame.font.SysFont("consolas", 20, bold=True)
    fonte_pequena = pygame.font.SysFont("consolas", 15)

    highscore = carregar_recorde()
    bolhas = [Bolha() for _ in range(28)]

    estado = "inicio"  # inicio | jogando | fim
    jogo = novo_jogo()

    rodando = True
    while rodando:
        relogio.tick(FPS)

        # O mergulho é mantido enquanto a tecla DOWN estiver pressionada.
        teclas = pygame.key.get_pressed()
        if estado == "jogando":
            if teclas[pygame.K_DOWN]:
                jogo["submarino"].iniciar_mergulho()
            else:
                jogo["submarino"].parar_mergulho()

        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                rodando = False

            elif evento.type == pygame.FINGERDOWN:
                # Android: toque na metade superior = subir; metade inferior = mergulhar.
                # Toque na tela de inicio = iniciar; no fim = reiniciar.
                tx = evento.x * LARGURA
                ty = evento.y * ALTURA
                if estado == "inicio":
                    estado = "jogando"
                elif estado == "jogando":
                    if ty < ALTURA * 0.62:
                        jogo["submarino"].pular()
                    else:
                        jogo["submarino"].iniciar_mergulho()
                elif estado == "fim":
                    jogo = novo_jogo()
                    estado = "jogando"

            elif evento.type == pygame.FINGERUP:
                if estado == "jogando":
                    jogo["submarino"].parar_mergulho()

            elif evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_ESCAPE:
                    rodando = False
                elif estado == "inicio" and evento.key in (pygame.K_SPACE, pygame.K_UP):
                    estado = "jogando"
                elif estado == "jogando":
                    if evento.key in (pygame.K_SPACE, pygame.K_UP):
                        jogo["submarino"].pular()
                    elif evento.key == pygame.K_DOWN:
                        jogo["submarino"].iniciar_mergulho()
                elif estado == "fim":
                    if evento.key == pygame.K_r:
                        jogo = novo_jogo()
                        estado = "jogando"
                    elif evento.key in (pygame.K_SPACE, pygame.K_RETURN):
                        jogo = novo_jogo()
                        estado = "jogando"

            elif evento.type == pygame.KEYUP:
                if evento.key == pygame.K_DOWN:
                    jogo["submarino"].parar_mergulho()

        for b in bolhas:
            b.atualizar()

        if estado == "jogando":
            colidiu, highscore = atualizar_jogando(jogo, highscore)
            if colidiu:
                estado = "fim"

        # --------------------------------------------------------------
        # DESENHO
        # --------------------------------------------------------------
        desenhar_gradiente_oceano(tela)
        for b in bolhas:
            b.desenhar(tela)
        desenhar_chao(tela, jogo["distancia"])

        for col in jogo["coletaveis"]:
            col.desenhar(tela)
        for obs in jogo["obstaculos"]:
            obs.desenhar(tela)
        jogo["submarino"].desenhar(tela)

        if estado in ("jogando", "fim"):
            txt_score = fonte_media.render(f"PONTOS: {int(jogo['pontuacao']):05d}", True, BRANCO)
            tela.blit(txt_score, (LARGURA - txt_score.get_width() - 20, 16))

            txt_recorde = fonte_pequena.render(f"RECORDE: {int(highscore):05d}", True, (210, 228, 245))
            tela.blit(txt_recorde, (LARGURA - txt_recorde.get_width() - 20, 46))

            txt_prof = fonte_pequena.render(f"PROFUNDIDADE: {int(jogo['distancia'] / 12)} m", True, (210, 228, 245))
            tela.blit(txt_prof, (20, 16))

        if estado == "inicio":
            titulo = fonte_grande.render("OCEAN EXPLORER", True, BRANCO)
            sub_titulo = fonte_media.render("Dino Runner de exploracao maritima", True, AZUL_SUPERFICIE)
            ctrl = fonte_media.render("ESPACO/CIMA: subir   BAIXO: mergulhar   ESC: sair", True, BRANCO)
            comecar = fonte_media.render("Pressione ESPACO para comecar", True, AMARELO)

            tela.blit(titulo, (LARGURA // 2 - titulo.get_width() // 2, 100))
            tela.blit(sub_titulo, (LARGURA // 2 - sub_titulo.get_width() // 2, 158))
            tela.blit(ctrl, (LARGURA // 2 - ctrl.get_width() // 2, 220))
            tela.blit(comecar, (LARGURA // 2 - comecar.get_width() // 2, 270))

        elif estado == "fim":
            overlay = pygame.Surface((LARGURA, ALTURA), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 130))
            tela.blit(overlay, (0, 0))

            titulo = fonte_grande.render("SUBMARINO PERDIDO!", True, VERMELHO)
            score_txt = fonte_media.render(f"Pontuacao final: {int(jogo['pontuacao'])}", True, BRANCO)
            recorde_txt = fonte_media.render(f"Recorde: {int(highscore)}", True, AMARELO)
            reinicio = fonte_media.render("Pressione R para tentar novamente", True, BRANCO)

            tela.blit(titulo, (LARGURA // 2 - titulo.get_width() // 2, 108))
            tela.blit(score_txt, (LARGURA // 2 - score_txt.get_width() // 2, 175))
            tela.blit(recorde_txt, (LARGURA // 2 - recorde_txt.get_width() // 2, 205))
            if jogo["novo_recorde"]:
                novo_txt = fonte_media.render("NOVO RECORDE!", True, DOURADO)
                tela.blit(novo_txt, (LARGURA // 2 - novo_txt.get_width() // 2, 235))
            tela.blit(reinicio, (LARGURA // 2 - reinicio.get_width() // 2, 272))

        pygame.display.flip()

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()